﻿using Book_Store_Api.Models;
using System.Collections.Generic;
using System.Linq;

namespace Online_Book_Store_Api.Repositories
{
	public class CartRepo : ICartRepo
	{
		private MyDbContext context;
		public CartRepo(MyDbContext _context)
		{
			context = _context;
		}
		public string AddnewCart(Cart cart)
		{
			int count = context.Cart.Count();
			context.Cart.Add(cart);
			context.SaveChanges();
			int newcount = context.Cart.Count();
			if(newcount>count)
			{
				return "Cart Added Successfully";
			}
			else
			{
				return "Something went wrong";
			}
		}

		public string DeleteCart(int Id)
		{
			Cart cart = context.Cart.Find(Id);
			if(cart != null)
			{
				context.Cart.Remove(cart);
				context.SaveChanges();
				return "Cart information is added successfully";
			}
			else
			{
				return "Cart information is not removed from the database";
			}
		}

		public List<Cart> GetAllCart()
		{
			return context.Cart.ToList();
		}

		public Cart GetCartById(int Id)
		{
			Cart cart = context.Cart.Find(Id);
			return cart;
		}

		public string UpdateCart(Cart cart)
		{
			Cart updatecart = context.Cart.Find(cart.Id);
			if(updatecart!=null)
			{
				updatecart.Title = cart.Title;
				context.Cart.Update(updatecart);
				context.SaveChanges();
				return "Cart information is updated";
			}
			else
			{
				return "Cart information is not available";
			}
		}
	}
}
