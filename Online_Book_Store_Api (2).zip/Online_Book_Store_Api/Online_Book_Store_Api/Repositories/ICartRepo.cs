﻿using Book_Store_Api.Models;
using System.Collections.Generic;

namespace Online_Book_Store_Api.Repositories
{
	public interface ICartRepo
	{
		List<Cart> GetAllCart();
		Cart GetCartById(int Id);
		public string AddnewCart(Cart cart);
		public string UpdateCart(Cart cart);
		public string DeleteCart(int Id);
		
	}
}
