﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Net.NetworkInformation;
using Microsoft.EntityFrameworkCore.ValueGeneration.Internal;
using System.Collections.Generic;


namespace Book_Store_Api.Models
{
	public class Cart
	{
		[Key]
		public int Id { get; set; }
		public string Title { get; set; }
		public int Qunatity { get; set; }
		public decimal Price { get; set; }
		public decimal TotalPrice { get; set; }
	    public Registration Registration { get; set; }
		public Book Book { get; set; }

	}
}
