﻿using Book_Store_Api.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Online_Book_Store_Api.Repositories;
using System.Collections.Generic;
using static System.Reflection.Metadata.BlobBuilder;

namespace Online_Book_Store_Api.Controllers
{
	[Route("api/[controller]")]
	[ApiController]
	public class CartController : ControllerBase
	{
		private readonly ICartRepo Repositories = null;
		public CartController(ICartRepo repo)
		{
			Repositories = repo;
		}
		[HttpGet]
		public ActionResult<List<Cart>> Get()
		{
			List<Cart> cart = Repositories.GetAllCart();
			if(cart.Count>0)
			{
				return cart;
			}
			else
			{
				return NotFound();
			}
		}
		[Route("{id:int}")]
		[HttpGet]
		public ActionResult<Cart> Get(int Id)
		{
			Cart cart = Repositories.GetCartById(Id);
			if(cart!=null)
			{
				return cart;
			}
			else
			{
				return NotFound();
			}
		}
		[HttpPost]
		public string Put(Cart cart)
		{
			string Response = Repositories.AddnewCart(cart);
			return Response;
		}
		
		[Route("{id:int}")]
		[HttpDelete]
		public string Delete(int Id)
		{
			string Response = Repositories.DeleteCart(Id);
			return Response;
		}
	}
}
